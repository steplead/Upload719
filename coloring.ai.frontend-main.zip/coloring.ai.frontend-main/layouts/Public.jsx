"use client"
import { useContext, useEffect } from 'react'
import Navbar from '../src/components/Navbar'
import { UserContext } from "../src/components/context/userContect";
export default function PublicLayout({ children }) {

    const { auth, setUser } = useContext(UserContext)
    useEffect(() => {
        const userToken = localStorage.getItem("ct");
        const user = JSON.parse(localStorage.getItem("cu"));
        if (userToken && user.email) {
            // mark user a login


            setUser({ user, token: userToken })
        }
    }, [])
    return (
        <>
            <Navbar />
            <main>{children}</main>
        </>
    )
}