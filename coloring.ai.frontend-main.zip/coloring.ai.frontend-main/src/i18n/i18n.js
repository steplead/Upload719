import i18n from "i18next";
import { initReactI18next } from "react-i18next";
// import LanguageDetector from 'i18next-browser-languagedetector';

import enJSON from "./translations/en";
import esJSON from "./translations/es";
import cnJSON from "./translations/cn";
import frJSON from "./translations/fr";
import arJSON from "./translations/ar";
import grJSON from "./translations/gr";
import urJSON from "./translations/ur";

const resources = {
    en: { translation: enJSON },
    es: { translation: esJSON },
    cn: { translation: cnJSON },
    fr: { translation: frJSON },
    ar: { translation: arJSON },
    gr: { translation: grJSON },
    ur: { translation: urJSON },
};

i18n
    // .use(LanguageDetector)
    .use(initReactI18next)
    .init({
        resources,
        // keySeparator: false,
        lng: "en",
        fallbackLng: "en",
        // react: {
        //     useSuspense: true,
        // },
        returnObjects: true,
        interpolation: {
            escapeValue: false,
        },
    });

export default i18n;