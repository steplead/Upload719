import React, { useContext, useEffect } from 'react'
import { UserContext } from '../components/context/userContect';
function UseAuth() {
    const { auth, setUser, logout } = useContext(UserContext)
    useEffect(() => {
        const userToken = localStorage.getItem("ct");
        const user = JSON.parse(localStorage.getItem("cu"));
        if (userToken && user.email) {
            // mark user a login
            setUser({ user, token: userToken })
        } else {
            logout()
        }
        return () => {
        }
    }, [])
    return auth
}

export default UseAuth