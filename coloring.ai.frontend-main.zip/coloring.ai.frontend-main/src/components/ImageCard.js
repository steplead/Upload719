import Image from 'next/image'
import React, { useContext } from 'react'
import { UserContext } from "../components/context/userContect";
import axios from 'axios';
import { toast } from 'react-toastify';

function ImageCard({ image, images, setImages }) {

    const { auth: { user: { name, role }, authenticated, token }, login } = useContext(UserContext);
    async function deleteImage(id) {
        console.log({ Authorization: `Bearer ${token}` });
        const request = await axios.delete(process.env.NEXT_PUBLIC_BASE_URL + `gallery/${id}`, {
            headers: {
                Authorization: `Bearer ${token}`
            },
        });
        const filterImage = images.filter(img => img._id !== id);
        setImages(filterImage);
        if (request.status == 200) {
            toast.success("Image deleted successfully")
        }
    }
    return (
        <div className="divvvv">
            <div className="rootDiv">
                {authenticated && role === "admin" && <button className="p-2 bg-red-600 text-white rounded" onClick={() => deleteImage(image._id)}>Delete</button>}
            </div>
            <div className="relative group">
                < div className="relative" >
                    <Image
                        src={image.imageUrl}
                        alt="Picture of the author"
                        width={485}
                        height={625}
                    />
                </div >
                <div className="absolute inset-0 bg-gray-900 bg-opacity-50 opacity-0 transition-opacity duration-300 ease-in-out group-hover:opacity-100 flex items-center justify-center">
                    <span className="text-white text-lg font-semibold">{image.alt}</span>
                </div>
            </div >
        </div>
    )
}

export default ImageCard