import React, { useState, useContext } from 'react'
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import Switch from '@mui/material/Switch';
import { useRouter, useParams } from 'next/navigation'
import { UserContext } from "./context/userContect";
import axios from 'axios';
import { toast } from 'react-toastify';

const label = { inputProps: { 'aria-label': 'Switch demo' } };
function Blog({ blog, deleteBlog }) {
    const [active, setActive] = useState(blog.isActive);

    const { auth: { user: { name, role }, authenticated, token }, login } = useContext(UserContext);

    const changeBlogStatus = async (id) => {
        try {
            const { data: { result } } = await axios.put(`${process.env.NEXT_PUBLIC_BASE_URL}blogs/${id}`, { isActive: !active }, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            setActive(!active);
        } catch (error) {
            toast.error("Something went worng")
        }
    }
    const router = useRouter();
    const { id } = useParams();
    return (
        <div key={blog._id} className="bg-white p-6 rounded-lg shadow-md" >
            {authenticated && role === "admin" && <div className="adminActions mb-2">
                <Switch {...label} checked={active} onClick={() => changeBlogStatus(blog._id)} className="cursor-pointer" />
                <DeleteIcon fontSize='medium' color='danger' onClick={() => deleteBlog(blog._id)} className="cursor-pointer" />
                <EditIcon onClick={() => router.push(`/blogs/${blog._id}/edit`)} className="cursor-pointer" />
            </div>}
            <img src={blog?.imageUrl} alt={blog?.title} className="w-full h-48 object-cover rounded-md" />
            <h3 className="mt-4 text-lg font-medium text-gray-900">{blog?.title ?? "title"}</h3>
            <p className="mt-2 text-gray-600">{blog?.description ?? "description"}</p>
            <p

                onClick={() => router.push(`/blogs/${blog._id}`)}
                className=" cursor-pointer mt-4 inline-block text-indigo-600 hover:text-indigo-800"
            >
                Read more
            </p>
        </div>
    )
}

export default Blog