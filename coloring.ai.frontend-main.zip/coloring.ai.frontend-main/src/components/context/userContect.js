"use client"
import axios from 'axios';
import React, { createContext, useState } from 'react';
import { ToastContainer, toast } from 'react-toastify';
export const UserContext = createContext();
import { useRouter } from "next/navigation"

const UserContextProvider = (props) => {
    const router = useRouter();
    const [auth, setAuth] = useState({
        authenticated: false,
        user: {},
        token: "",
    });
    const login = async ({ email, pass }) => {
        try {
            const { data: { result: { user: { role }, token } }, status } = await axios.post(process.env.NEXT_PUBLIC_BASE_URL + `auth/signin`, { email, password: pass, });
            const user = {
                name: email.split('@')[0],
                email,
                role,
            }
            setAuth({
                authenticated: true,
                user,
                token
            })
            localStorage.setItem('cu', JSON.stringify(user))
            localStorage.setItem("ct", token)
            router.push("/")


        } catch (error) {
            const { response: { data } } = error
            throw new Error(data.message || error.message)
        }
    }
    const logout = () => {
        localStorage.removeItem('cu')
        localStorage.removeItem("ct")
        setAuth({
            authenticated: false,
            user: {}
        })
    }
    const signup = async ({ email, password, role }) => {
        try {
            const { data: { result: { token } }, status } = await axios.post(process.env.NEXT_PUBLIC_BASE_URL + `auth/signup`, { email, password, role });
            const user = {
                name: email.split('@')[0],
                email,
                role,
            }
            setAuth({
                authenticated: true,
                user,
                token
            })
            localStorage.setItem('cu', JSON.stringify(user))
            localStorage.setItem("ct", token)
            router.push("/")


        } catch (error) {
            const { response: { data } } = error
            throw new Error(data.message || error.message)
        }
    }
    const setUser = (user, token) => {

        const newObjectect = {
            authenticated: true,
            user,
            token
        }
        setAuth(newObjectect)
        return
    }

    return (
        <UserContext.Provider value={{ login, logout, signup, auth, setUser }}>
            {props.children}
            <ToastContainer theme='dark' />
        </UserContext.Provider>
    )
}
export default UserContextProvider;