"use client"
import React, { createContext, useState } from 'react';
export const LanguageContext = createContext();

const LanguageContextProvider = (props) => {
    const [language, setLanguage] = useState("es");
    const changeLanguage = language => setLanguage(language)

    return (
        <LanguageContext.Provider value={{ language, changeLanguage }}>
            {props.children}
        </LanguageContext.Provider>
    )
}
export default LanguageContextProvider;