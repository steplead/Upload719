import { IconButton, styled } from '@mui/material';

const IconButtonWrapper = styled(IconButton)(
    ({ theme }) => `
        width: ${theme.spacing(6)};
        height: ${theme.spacing(6)};

        svg {
          width: 28px;
        }
`
);

export default IconButtonWrapper;