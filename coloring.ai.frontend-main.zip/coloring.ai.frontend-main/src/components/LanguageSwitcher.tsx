"use client";
import internationalization from "../i18n/i18n";
import {
    Box,
    Divider,
    List,
    ListItem,
    ListItemText,
    Popover,
    Tooltip,
} from "@mui/material";
import IconButtonWrapper from "./IconButtonWrapper";
import SectionHeading from "./SectionHeading";
import { AE, CN, DE, ES, FR, GR, US, PK, CH, AR, GE, SA, } from "country-flag-icons/react/3x2";
import { useRef, useState } from "react";
import { useTranslation } from "react-i18next";
//
function LanguageSwitcher({ disabled }: any) {
    const { i18n } = useTranslation();
    const { t } = useTranslation();
    const getLanguage = i18n.language;

    const switchLanguage = ({ lng }: { lng: string }) => {
        internationalization.changeLanguage(lng);

    };
    const ref = useRef(null);
    const [isOpen, setOpen] = useState(false);

    const handleOpen = () => {
        if (!disabled) {
            setOpen(true);
        }
    };

    const handleClose = () => {
        setOpen(false);
    };

    return (
        <>
            <Tooltip
                arrow
                title={t("Language Switcher")}
                style={{
                    fontSize: "44px",
                }}
            >
                <IconButtonWrapper
                    color="secondary"
                    ref={ref}
                    onClick={handleOpen}
                    sx={{
                        fontSize: "44px",
                        cursor: disabled ? "not-allowed" : "pointer",
                    }}
                >
                    {getLanguage === "en" && <US title="English" />}
                    {getLanguage === "en-US" && <US title="English" />}
                    {getLanguage === "en-GB" && <US title="English" />}
                    {getLanguage === "es" && <ES title="Urdu" />}
                    {getLanguage === "ur" && <PK title="Urdu" />}
                    {getLanguage === "fr" && <FR title="French" />}
                    {getLanguage === "cn" && <CN title="Chinese" />}
                    {getLanguage === "gr" && <DE title="German" />}
                    {getLanguage === "ar" && <SA title="Saudi Arabia" />}
                </IconButtonWrapper>
            </Tooltip>
            <Popover
                disableScrollLock
                anchorEl={ref.current}
                onClose={handleClose}
                open={isOpen}
                anchorOrigin={{
                    vertical: "top",
                    horizontal: "right",
                }}
                transformOrigin={{
                    vertical: "top",
                    horizontal: "right",
                }}
            >
                <Box
                    sx={{
                        maxWidth: 240,
                    }}
                >
                    <SectionHeading variant="body2" color="text.primary">
                        {t("Language Switcher")}
                    </SectionHeading>
                    <List
                        sx={{
                            p: 2,
                            svg: {
                                width: 26,
                                mr: 1,
                            },
                        }}
                        component="nav"
                    >
                        <ListItem
                            className={
                                getLanguage === "en" || getLanguage === "en-US" ? "active" : ""
                            }
                            button
                            onClick={() => {
                                switchLanguage({ lng: "en" });
                                handleClose();
                            }}
                        >
                            <US title="English" />
                            <ListItemText
                                sx={{
                                    pl: 1,
                                }}
                                primary="English"
                            />
                        </ListItem>

                        <ListItem
                            className={getLanguage === "ur" ? "active" : ""}
                            button
                            onClick={() => {
                                switchLanguage({ lng: "ur" });
                                handleClose();
                            }}
                        >
                            <PK title="Urdu" />
                            <ListItemText
                                sx={{
                                    pl: 1,
                                }}
                                primary="Urdu"
                            />
                        </ListItem>
                        <ListItem
                            className={getLanguage === "es" ? "active" : ""}
                            button
                            onClick={() => {
                                switchLanguage({ lng: "es" });
                                handleClose();
                            }}
                        >
                            <ES title="Spanish" />
                            <ListItemText
                                sx={{
                                    pl: 1,
                                }}
                                primary="Spanish"
                            />
                        </ListItem>
                        <ListItem
                            className={getLanguage === "ar" ? "active" : ""}
                            button
                            onClick={() => {
                                switchLanguage({ lng: "ar" });
                                handleClose();
                            }}
                        >
                            <SA title="Arabic" />
                            <ListItemText
                                sx={{
                                    pl: 1,
                                }}
                                primary="Arabic"
                            />
                        </ListItem>
                        <ListItem
                            className={getLanguage === "cn" ? "active" : ""}
                            button
                            onClick={() => {
                                switchLanguage({ lng: "cn" });
                                handleClose();
                            }}
                        >
                            <CN title="Chinese" />
                            <ListItemText
                                sx={{
                                    pl: 1,
                                }}
                                primary="Chinese"
                            />
                        </ListItem>
                        <ListItem
                            className={getLanguage === "gr" ? "active" : ""}
                            button
                            onClick={() => {
                                switchLanguage({ lng: "gr" });
                                handleClose();
                            }}
                        >
                            <DE title="German" />
                            <ListItemText
                                sx={{
                                    pl: 1,
                                }}
                                primary="German"
                            />
                        </ListItem>
                        <ListItem
                            className={getLanguage === "fr" ? "active" : ""}
                            button
                            onClick={() => {
                                switchLanguage({ lng: "fr" });
                                handleClose();
                            }}
                        >
                            <FR title="French" />
                            <ListItemText
                                sx={{
                                    pl: 1,
                                }}
                                primary="French"
                            />
                        </ListItem>
                    </List>
                    <Divider />
                </Box>
            </Popover>
        </>
    );
}

export default LanguageSwitcher;