"use client"
import { useContext, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Logout from '@mui/icons-material/Logout';
import { UserContext } from './context/userContect';

const withAuth = (WrappedComponent) => {
    return function Auth(props) {
        const router = useRouter();
        const { auth, setUser, logout } = useContext(UserContext)
        useEffect(() => {
            if (auth.authenticated && auth.token) return
            const userToken = localStorage.getItem("ct");
            const user = JSON.parse(localStorage.getItem("cu"));
            if (userToken && user.email) {
                // mark user a login
                const token = userToken;
                setUser(user, token);
            } else {
                logout()
            }
            return () => {
            }
        }, [router, auth.authenticated, auth.token])

        return <WrappedComponent {...props} />;
    };
};

export default withAuth;
