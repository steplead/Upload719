import PublicLayout from "../layouts/Public"
import '../styles/globals.css';
import UserContextProvider from "../src/components/context/userContect"
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from "react-toastify";

export default function RootLayout({ children, params: { lng } }) {
  return (
    <html>

      <body>
        <UserContextProvider>
          <PublicLayout>
            {children}
          </PublicLayout>
        </UserContextProvider>
      </body>

    </html>
  )
}
