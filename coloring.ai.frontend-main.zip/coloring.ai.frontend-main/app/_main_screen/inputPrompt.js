import React from 'react'

function inputPrompt() {
    return (
        <section class="flex flex-col py-6 md:py-16 ">
            <div class="flex flex-col py-16 px-4 md:p-16 bg-[#C0EEE4]">
                <div class="text-center">
                    <h1 class="text-3xl md:text-5xl font-semibold mb-4">Free Coloring Pages</h1>
                </div>
            </div>
        </section>

    )
}

export default inputPrompt