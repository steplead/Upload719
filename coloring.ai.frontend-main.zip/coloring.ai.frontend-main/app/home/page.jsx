import React from 'react'
import withAuth from "../../src/components/withAuth"
function Home() {
    return (
        <div>page</div>
    )
}

export default Home;