"use client"
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useParams } from "next/navigation"
import Image from 'next/image';
import ReactHtmlParser from "react-html-parser"
import withAuth from "../../../src/components/withAuth"
function ViewBlog() {

    const [blog, setBlog] = useState({})
    const { id } = useParams()
    const fetchBlog = async () => {
        const { data: { result }, status } = await axios.get(process.env.NEXT_PUBLIC_BASE_URL + `blogs/${id}`);
        if (status !== 200) return false;
        setBlog(result);
    }
    useEffect(() => {
        fetchBlog();
    }, []);
    return (
        <div className="pt-16 min-h-screen flex items-center justify-center bg-gray-100">
            <div className="bg-white p-8 rounded shadow-lg w-full max-w-3xl">
                <Image src={blog.imageUrl} objectFit="fit" alt={blog.title} width={400} height={250} className="w-full h-auto rounded" />
                <h1 className="text-3xl font-bold mt-4">{blog.title}</h1>
                <p className="mt-4 text-gray-700">{ReactHtmlParser(blog.content)}</p>
            </div>
        </div>
    )
}

export default withAuth(ViewBlog)