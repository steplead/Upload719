"use client"
import axios from 'axios';
import React, { useEffect, useContext, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { UserContext } from "../../src/components/context/userContect";
import Blog from "../../src/components/Blog";
import { ToastContainer, toast } from 'react-toastify';
import { useRouter } from 'next/navigation'
import withAuth from "../../src/components/withAuth"


const Blogs = () => {
    const [blogs, setBlogs] = useState([]);
    const router = useRouter();
    const { auth: { user: { name, role }, authenticated, token }, login } = useContext(UserContext);
    const fetchBlogs = async () => {
        let URL = `${process.env.NEXT_PUBLIC_BASE_URL}blogs`
        if (authenticated && role === "admin") URL += `?status=all`
        const { data: { result } } = await axios.get(URL);
        setBlogs(result)
    }
    const deleteBlog = async (id) => {
        // call delete api
        const { data: { result }, status } = await axios.delete(`${process.env.NEXT_PUBLIC_BASE_URL}blogs/${id}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        if (status !== 200) return false;
        const removeDeletedBlogs = blogs.filter(blog => blog._id !== id);
        setBlogs(removeDeletedBlogs);
        toast.success("🎉 Blog deleted successfully.")
    }
    useEffect(() => {
        fetchBlogs();

    }, [authenticated]);
    const { t } = useTranslation()
    return (
        <section className="bg-gray-100 py-36 h-screen">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center">
                    <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
                        {t('blogs.title')}
                    </h2>
                    <p className="mt-4 text-lg leading-6 text-gray-600">
                        {t('blogs.subheading')}
                    </p>
                </div>
                {authenticated && role === "admin" && <div className="text-start">
                    <button className="text-2xl p-3 rounded font-extra  text-white  bg-sky-600" onClick={() => router.push("/blogs/create")}>
                        Create Blog
                    </button>

                </div>}

                <div className="mt-12 grid gap-8 lg:grid-cols-3">
                    {blogs.map((blog) => (
                        <Blog key={blog._id} blog={blog} deleteBlog={deleteBlog} />
                    ))}
                </div>
            </div>
            <ToastContainer theme="dark" />
        </section>
    );
};

export default withAuth(Blogs);
