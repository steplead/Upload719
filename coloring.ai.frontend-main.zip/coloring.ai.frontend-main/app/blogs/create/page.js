"use client";
import axios from 'axios';
import React, { useContext, useEffect, useState } from 'react'
import { useParams, useRouter } from "next/navigation";
import CustomEditor from "../../../src/components/ckEditor"
import Image from 'next/image';
import { ToastContainer, toast } from 'react-toastify';
import { Switch } from '@mui/material';
import withAuth from "../../../src/components/withAuth"
import { UserContext } from '../../../src/components/context/userContect';

const label = { inputProps: { 'aria-label': 'Switch demo' } };
function EditBlog() {
    const { auth: { user: { name, role }, authenticated, token }, login } = useContext(UserContext);
    const [title, setTitle] = useState("")
    const [desc, setDesc] = useState("")
    const [imgUrl, setImgUrl] = useState("")
    const [content, setContent] = useState("")
    const [isActive, setIsActive] = useState(true)
    const router = useRouter()

    const handleSubmit = async (e) => {
        e.preventDefault();
        const expression = /[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/gi;
        const regex = new RegExp(expression);
        if (!title || !desc || !imgUrl || !content) {
            toast.error("All fields are requried")
            return
        }
        if (!imgUrl.match(regex)) {
            toast.error("Please input a valid url.")
            return
        }
        // Handle signup logic here
        try {
            const { data: { result }, status } = await axios.post(process.env.NEXT_PUBLIC_BASE_URL + `blogs/`, { title, description: desc, imageUrl: imgUrl, content, isActive }, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            if (status !== 201) return false;
        } catch (error) {
            toast.error("Something went wrong.")
            return false
        }
        toast.success("🎉 Blog created successfully.")
        setTitle("")
        setDesc("")
        setImgUrl("")
        setContent("")
        router.push("/blogs")

    }
    useEffect(() => {
        // fetchBlog();
    }, []);
    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100">
            <div className="bg-white p-8 rounded shadow-lg w-full max-w-3xl">
                <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="title">
                            Title
                        </label>
                        <input
                            id="title"
                            type="title"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            required
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:border-blue-300"
                        />
                    </div>
                    <div className="mb-6">
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
                            description
                        </label>
                        <input
                            id="desc"
                            type="desc"
                            value={desc}
                            onChange={(e) => setDesc(e.target.value)}
                            required
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:border-blue-300"
                        />
                    </div>
                    <div className="mb-6">
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
                            Image URL
                        </label>
                        <input
                            id="imgUrl"
                            type="imgUrl"
                            value={imgUrl}
                            onChange={(e) => setImgUrl(e.target.value)}
                            required
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:border-blue-300"
                        />
                    </div>
                    <div className="mb-6">
                        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
                            Active
                        </label>
                        <Switch {...label} defaultChecked={true} onClick={(e) => setIsActive(!isActive)} />
                    </div>
                    <CustomEditor initialData={content} setContent={setContent} />
                    <div className="flex items-center justify-between">
                        <button
                            type="submit"
                            className="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                        >
                            Create
                        </button>
                    </div>
                </form>
            </div>
            <ToastContainer theme="dark" />
        </div>

    )
}

export default withAuth(EditBlog)