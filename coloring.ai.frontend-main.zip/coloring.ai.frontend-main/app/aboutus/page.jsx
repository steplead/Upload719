"use client"
import React from 'react';
import { useTranslation } from 'react-i18next';
import withAuth from '@/src/components/withAuth';
const AboutUs = () => {
    const { t } = useTranslation()
    return (
        <section className="bg-gray-100 pt-36 h-screen">
            <div className="container mx-auto px-6 md:px-12">
                <h2 className="text-3xl font-extrabold text-gray-800 mb-4">{t('aboutus.title')}</h2>
                <p className="text-lg text-gray-700 mb-6">
                    {t('aboutus.subheading')}
                </p>
                <div className="flex flex-wrap -mx-3">
                    <div className="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                        <div className="bg-white p-6 rounded-lg shadow-lg">
                            <h3 className="text-xl font-bold text-gray-800 mb-3">  {t('aboutus.card_vision.title')}</h3>
                            <p className="text-gray-700">
                                {t('aboutus.card_vision.subheading')}
                            </p>
                        </div>
                    </div>
                    <div className="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                        <div className="bg-white p-6 rounded-lg shadow-lg">
                            <h3 className="text-xl font-bold text-gray-800 mb-3">{t('aboutus.card_technology.title')}</h3>
                            <p className="text-gray-700">
                                {t("aboutus.card_technology.subheading")}
                            </p>
                        </div>
                    </div>
                    <div className="w-full md:w-1/3 px-3">
                        <div className="bg-white p-6 rounded-lg shadow-lg">
                            <h3 className="text-xl font-bold text-gray-800 mb-3">{t('aboutus.card_team.title')}</h3>
                            <p className="text-gray-700">
                                {t('aboutus.card_team.subheading')}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section >
    );
};

export default withAuth(AboutUs);
