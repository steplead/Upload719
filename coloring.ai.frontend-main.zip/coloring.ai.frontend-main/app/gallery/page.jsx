"use client"
import Image from 'next/image';
import React, { useContext, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import ImageCard from "@/src/components/ImageCard"
import withAuth from '@/src/components/withAuth';
import axios from 'axios';

const Gallery = () => {
    const [images, setImages] = useState([]);

    const fetchImages = async () => {
        let URL = `${process.env.NEXT_PUBLIC_BASE_URL}gallery`
        const { data: { result } } = await axios.get(URL);
        setImages(result)
    }
    const deleteBlog = async (id) => {
        // call delete api
        const { data: { result }, status } = await axios.delete(`${process.env.NEXT_PUBLIC_BASE_URL}blogs/${id}`);
        if (status !== 200) return false;
        const removeDeletedBlogs = blogs.filter(blog => blog._id !== id);
        setBlogs(removeDeletedBlogs);
        toast.success("🎉 Blog deleted successfully.")
    }
    useEffect(() => {
        fetchImages();

    }, []);


    const { t } = useTranslation();
    return (
        <section className="bg-white py-36 h-screen">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center">
                    <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
                        {t('gallery.title')}
                    </h2>
                    <p className="mt-4 text-lg leading-6 text-gray-600">
                        {t('gallery.subheading')}
                    </p>
                </div>
                <div className="mt-12 grid gap-8 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                    {images.reverse().map((image) => (
                        <ImageCard key={image._id} image={image} images={images} setImages={setImages} />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default withAuth(Gallery);