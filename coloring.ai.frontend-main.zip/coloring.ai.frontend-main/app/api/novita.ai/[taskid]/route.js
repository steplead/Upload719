
import axios from "axios"
import { NextResponse, NextRequest } from 'next/server';

export async function GET(request, { params }) {
    const { taskid: taskId } = params;
    if (!taskId) {
        return new NextResponse(JSON.stringify({ message: 'task_id is required' }), {
            status: 400,
            headers: { 'Content-Type': 'application/json' },
        });
    }

    const apiKey = process.env.NOVITA_API_KEY; // Ensure you have this key set in your environment variables

    try {
        const response = await axios.get(`https://api.novita.ai/v3/async/task-result`, {
            params: { task_id: taskId },
            headers: {
                Authorization: `Bearer ${apiKey}`,
            },
        });

        return new NextResponse(JSON.stringify(response.data), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
        });
    } catch (error) {
        return new NextResponse(JSON.stringify({ message: `Internal Server Error, ${error.message}` }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' },
        });
    }
}