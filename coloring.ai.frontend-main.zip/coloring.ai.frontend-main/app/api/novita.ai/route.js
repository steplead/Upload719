import axios from "axios"
import { NextResponse, NextRequest } from 'next/server';


export async function POST(request) {
    try {
        const { prompt } = await request.json();
        if (!prompt) {
            return new NextResponse(JSON.stringify({ message: 'Prompt is required' }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' },
            });
        }

        const apiKey = process.env.NOVITA_API_KEY; // Ensure you have this key set in your environment variables

        const data = {
            extra: {
                response_image_type: 'jpeg',
            },
            request: {
                "prompt": `create a black and white line drawing for a coloring book. Ensure that the result is strictly limited to black, and white color. ${prompt}.`,
                "model_name": "majicmixRealistic_v6_65516.safetensors",
                "negative_prompt": "nsfw, bottle, bad face",
                "width": 485,
                "height": 625,
                "steps": 20,
                "seed": -1,
                "clip_skip": 1,
                "sampler_name": "Euler a",
                "guidance_scale": 7.5,
                image_num: 2,
            },
        };

        const response = await axios.post('https://api.novita.ai/v3/async/txt2img', data, {
            headers: {
                Authorization: `Bearer ${apiKey}`,
                'Content-Type': 'application/json',
            },
        });
        return new NextResponse(JSON.stringify(response.data), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
        });
    } catch (error) {
        return new NextResponse(JSON.stringify({ message: `Internal Server Error, ${error.message}` }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' },
        });
    }
}