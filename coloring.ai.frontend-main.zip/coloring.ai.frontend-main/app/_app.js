import { NextIntlClientProvider } from 'next-intl';
import { useRouter, useContext } from 'next/router';
import UserContext from "../src/components/context/userContect"
export default function App({ Component, pageProps }) {
    const router = useRouter();
    const { auth, setUser } = useContext(UserContext)
    useEffect(() => {
        const userToken = localStorage.getItem("ct");
        const user = JSON.parse(localStorage.getItem("cu"));
        if (userToken && user.email) {
            // mark user a login
            setUser({ user, token: userToken })
        }
        return () => {
        }
    }, [])
    return (
        <NextIntlClientProvider
            locale={router.locale}
            timeZone="Europe/Vienna"
            messages={pageProps.messages}
        >
            <Component {...pageProps} />
        </NextIntlClientProvider>
    );
}