'use client';

import Image from "next/image";
import { useState, useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import axios from "axios";
import CircularProgress from '@mui/material/CircularProgress';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import UseAuth from "../src/hooks/useAuth"
import withAuth from "@/src/components/withAuth";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function Home() {
    const { t, i18n } = useTranslation();
    const [tryPrompts, setPrompts] = useState(t("home.ai_suggestions"));
    const [error, setError] = useState(null);
    const promptInputRef = useRef(null);
    const [finalImage, setFinalImage] = useState([{
        image_url: "https://storage.googleapis.com/temp-color/67352377-7497-4887-b426-ddee1b8c8ada.jpeg"
    }])

    const auth = UseAuth();
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        promptInputRef.current.focus();
    }, []);

    const handleLanguageChanged = () => {
        setPrompts(t("home.ai_suggestions"));
    };

    useEffect(() => {
        i18n.on('languageChanged', handleLanguageChanged);
        return () => {
            i18n.off('languageChanged', handleLanguageChanged);
        };
    }, [i18n]);

    const handleSubmit = async (e) => {
        try {
            e.preventDefault();
            if (!e.target.prompt.value) {
                toast.warn("☹️ Input Prompt is required.")
                return
            }
            setLoading(true);

            const { data: { result }, status } = await axios.post(process.env.NEXT_PUBLIC_BASE_URL + `gallery/generate`, { prompt: `${e.target.prompt.value}` });
            let prediction = result;
            if (!prediction.task_id) {
                setLoading(false);
                setError("Something went wrong");
                return;
            }

            // fetch the reulsts using taskid
            let predictionStatus = 0;
            let predictionResults = null;
            while (predictionStatus === 0) {
                await sleep(2000)
                predictionResults = await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}gallery/generate/${prediction.task_id}`);
                const { task: { status, }, images } = predictionResults.data.result;
                if (images.length) {
                    predictionStatus = 1;
                    setFinalImage([images[0]]);
                    setLoading(false);
                    toast.success("🎉 Your Ai images has been generated successfully.")
                }
            }

            // once the image is created save them to the database
            const { data: { result: { images } } } = predictionResults
            const arrayOfImages = images.map(image => {
                return {
                    imageUrl: image.image_url,
                }
            });
            const { result: savedImages } = await axios.post(process.env.NEXT_PUBLIC_BASE_URL + "gallery", {
                imageUrl: arrayOfImages
            })
        } catch (error) {
            console.log("error", error.message)
        }
    };

    return (
        <section className="flex flex-col pt-6 md:pt-16">
            <div className="flex flex-col py-16 px-4 md:p-6 bg-[#C0EEE4]">
                <div className="text-center">
                    <h1 className="text-3xl md:text-5xl font-semibold mb-4">{t('home.title')}</h1>
                </div>
                <div className="my-4 text-center">
                    <h2 className="text-2xl md:text-3xl font-semibold mb-4">{t('home.sub_heading')}</h2>
                </div>
                <form className="flex flex-col xl:flex-row justify-center text-xl" onSubmit={handleSubmit}>
                    <input
                        type="text"
                        className="p-4 rounded-xl border-2 border-[#270722] w-full mr-4 xl:max-w-[600px] mb-4 xl:mb-0"
                        name="prompt"
                        placeholder={t('home.input_prompt_placeholder')}
                        ref={promptInputRef}
                    />
                    <button className="flex justify-between p-4 px-8 text-xl rounded-xl bg-[#270722] text-white tracking-wide hover:cursor-pointer hover:bg-[#450c3c]" type="submit">
                        {loading ? t("home.processing_image") : t("home.button_for_creating_ai_image")}
                        {loading && <div className="pl-4">
                            <CircularProgress size={30} thickness={5} sx={{
                                color: "white"
                            }} />
                        </div>
                        }
                    </button>
                </form>
                <div className="flex flex-col md:flex-row items-center justify-center mt-8">
                    <div className="text-sm text-gray-700 mr-2 mb-2 md:mb-0">{t("home.try_these")}</div>
                    <div className="flex flex-row flex-wrap gap-2 justify-center">
                        {tryPrompts.map((prompt, index) => (
                            <div
                                key={index}
                                className="rounded-lg px-4 py-2 text-sm whitespace-nowrap text-center text-gray-800 shadow-sm border-[1px] border-gray-300 hover:cursor-pointer bg-white"
                                onClick={() => {
                                    if (promptInputRef.current) promptInputRef.current.value = prompt
                                    return true
                                }}
                            >
                                {prompt}
                            </div>
                        ))}
                    </div>
                </div>
            </div>
            <div className="h-2/5 bg-[#F8F988] p-2 pt-4 md:p-6 flex justify-center">
                {finalImage.map((img, i) => (
                    <div className="relative w-2/5 flex justify-center" key={i}>
                        <Image
                            src={img.image_url}
                            alt="Picture of the author"
                            width={485}
                            height={625}
                            style={{
                                objectFit: 'contain',
                            }}
                        />
                    </div>
                ))}
            </div>

            {/* Banner section */}

            {error && <div>{error}</div>}
            <ToastContainer theme="dark" />

        </section >
    );
}

export default withAuth(Home);
