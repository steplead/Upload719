import { app, ENV, DB } from "./src/config/index.js";
import GlobalErrorHandler from "./src/middlewares/GlobalErrorHandler.js";
import AppRoutes from "./src/routes/index.js";


// App routes
app.use("/api/v1", AppRoutes);

// handling route not found!
app.use(GlobalErrorHandler.apiNotFound);

app.use(GlobalErrorHandler.trustedError);

app.listen(ENV.PORT, async () => {
  await DB();
  console.log(`coloring ai backend running on ${ENV.PORT} port`);
});