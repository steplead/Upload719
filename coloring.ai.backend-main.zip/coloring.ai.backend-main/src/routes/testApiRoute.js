import { Router } from "express";
import testApi from "../controllers/testApi.js";
import permissionMiddleware from "../middlewares/permissionMiddleware.js";
import authMiddleware from "../middlewares/authMiddleware.js";

const router = Router();
router.get("/", authMiddleware, permissionMiddleware, testApi);
export default router;