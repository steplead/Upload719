import { Router } from "express";
import { createBlog, updateBlog, deleteBlog, getBlogs, getABlog } from "../controllers/blog/blog.js";
import authMiddleware from "./../middlewares/authMiddleware.js";
import permissionMiddleware from "./../middlewares/permissionMiddleware.js";

const router = Router();
router.get("/", getBlogs);
router.get("/:id", getABlog);
router.post("/", authMiddleware, permissionMiddleware, createBlog);
router.put("/:id", authMiddleware, permissionMiddleware, updateBlog);
router.delete("/:id", authMiddleware, permissionMiddleware, deleteBlog);
export default router;