import { Router } from "express";
import signUp from "../controllers/auth/signUp.js";
import signIn from "../controllers/auth/signIn.js";
import current from "../controllers/auth/current.js";
import RequiredFiedldsMiddleware from "../middlewares/requireFieldsMiddleware.js";
import { SignUpJoiSchema, SignInJoiSchema } from "../constants/joiValidation.js";
import authMiddleware from "../middlewares/authMiddleware.js";

const router = Router();
router.post("/signup", RequiredFiedldsMiddleware(SignUpJoiSchema), signUp);
router.post("/signin", RequiredFiedldsMiddleware(SignInJoiSchema), signIn);
router.get("/current", authMiddleware, current);
export default router;