import { Router } from "express";
import { deleteImage, generateImage, getGallery, imageGenerationStatus, saveImage, } from "../controllers/gallery/getGallery.js";
import authMiddleware from "./../middlewares/authMiddleware.js";

const router = Router();
router.get("/", getGallery);
router.delete("/:id", authMiddleware, deleteImage);
router.post("/", saveImage);
router.post("/generate", generateImage);
router.get("/generate/:id", imageGenerationStatus);
export default router;