import { Router } from "express";
import testApiRoute from "./testApiRoute.js";
import authRoutes from "./authRoutes.js";
import blogRoutes from "./blogRoutes.js";
import galleryRoutes from "./gallery.js";

const router = Router();
router.use("/test", testApiRoute);
router.use("/auth", authRoutes);
router.use("/blogs", blogRoutes);
router.use("/gallery", galleryRoutes);
export default router;