import Gallery from "../../models/gallery.js";
import { ApiError } from "../../utils/ApiErrors.js";
import { SuccessResponse } from "../../utils/index.js";
import axios from "axios";

export const getGallery = async (req, res, next) => {
    try {
        const gallery = await Gallery.find({}).sort({ createdAt: -1 });
        if (!gallery) {
            throw new ApiError("Not Found", 404, true, false, "Blog not found");
        }
        return new SuccessResponse(res, 200, true, gallery)
    } catch (error) {
        next(error)
    }
};

export const deleteImage = async (req, res, next) => {
    try {
        const imageId = req.params.id;
        const deletedImage = await Gallery.deleteOne({ _id: imageId });
        if (!deletedImage) {
            throw new ApiError("Not Found", 404, true, false, "Something went worng");
        }
        return new SuccessResponse(res, 200, true, "Blog deleted successfully");
    } catch (error) {
        next(error)
    }
};

export const saveImage = async (req, res, next) => {
    try {
        const imageUrl = req.body.imageUrl;
        const createdImage = await Gallery.insertMany(imageUrl);
        if (!createdImage) {
            throw new ApiError("Not Found", 404, true, false, "Something went worng");
        }
        return new SuccessResponse(res, 200, true, createdImage);
    } catch (error) {
        next(error)
    }
};

export const generateImage = async (req, res, next) => {
    try {
        const { prompt } = req.body;
        if (!prompt) {
            throw new ApiError("prompt", 400, true, true, "prompt not found")
        }

        const apiKey = process.env.NOVITA_API_KEY; // Ensure you have this key set in your environment variables

        const data = {
            extra: {
                response_image_type: 'jpeg',
            },
            request: {
                "prompt": `create a black and white line drawing for a coloring book. Ensure that the result is strictly limited to black, and white color. ${prompt}.`,
                "model_name": "majicmixRealistic_v6_65516.safetensors",
                "negative_prompt": "nsfw, bottle, bad face",
                "width": 485,
                "height": 625,
                "steps": 20,
                "seed": -1,
                "clip_skip": 1,
                "sampler_name": "Euler a",
                "guidance_scale": 7.5,
                image_num: 2,
            },
        };

        const response = await axios.post('https://api.novita.ai/v3/async/txt2img', data, {
            headers: {
                Authorization: `Bearer ${apiKey}`,
                'Content-Type': 'application/json',
            },
        });

        return new SuccessResponse(res, 200, true, response.data);
    } catch (error) {
        next(error)
    }
};

export const imageGenerationStatus = async (req, res, next) => {
    const { id: taskId } = req.params;
    if (!taskId) {
        throw new ApiError("prompt", 400, true, true, "taskId not found")
    }

    const apiKey = process.env.NOVITA_API_KEY; // Ensure you have this key set in your environment variables

    try {
        const response = await axios.get(`https://api.novita.ai/v3/async/task-result`, {
            params: { task_id: taskId },
            headers: {
                Authorization: `Bearer ${apiKey}`,
            },
        });

        return new SuccessResponse(res, 200, true, response.data);
    } catch (error) {
        next(error)
    }
};

