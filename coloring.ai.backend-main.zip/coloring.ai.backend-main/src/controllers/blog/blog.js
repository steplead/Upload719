import { ApiError, SuccessResponse } from "../../utils/index.js";
import Blogs from "../../models/blogSchema.js";

export const createBlog = async (req, res, next) => {
  try {
    const { body } = req;
    const blog = await Blogs.create({
      ...body
    });
    return new SuccessResponse(res, 201, true, blog)
  } catch (error) {
    next(error)
  }
};
export const updateBlog = async (req, res, next) => {
  try {
    const { body: { content }, params: { id } } = req;
    const blog = await Blogs.findOneAndUpdate({ _id: id }, { $set: req.body }, { new: true });
    return new SuccessResponse(res, 200, true, blog)
  } catch (error) {
    next(error)
  }
};
export const deleteBlog = async (req, res, next) => {
  try {
    const { params: { id } } = req;
    await Blogs.findOneAndDelete({ _id: id });
    return new SuccessResponse(res, 200, true, "Blog Deleted")
  } catch (error) {
    next(error)
  }
};
export const getBlogs = async (req, res, next) => {
  try {
    const query = {}
    if (req.query.status !== "all") {
      query.isActive = true
    }
    const blogs = await Blogs.find(query);
    if (!blogs) {
      throw new ApiError("Not Found", 404, true, false, "Blog not found");
    }
    return new SuccessResponse(res, 200, true, blogs)
  } catch (error) {
    next(error)
  }
};
export const getABlog = async (req, res, next) => {
  try {
    const { id } = req.params
    const blogs = await Blogs.findOne({ _id: id });
    if (!blogs) {
      throw new ApiError("Not Found", 404, true, false, "Blog not found");
    }
    return new SuccessResponse(res, 200, true, blogs)
  } catch (error) {
    next(error)
  }
}