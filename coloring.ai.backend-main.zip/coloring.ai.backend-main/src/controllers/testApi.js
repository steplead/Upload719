import { SuccessResponse } from "../utils/index.js";

const testApi = async (req, res, next) => {
  try {
    return new SuccessResponse(res, 200, true, "Test Api");
  } catch (error) {
    next(error)
  }
};
export default testApi;