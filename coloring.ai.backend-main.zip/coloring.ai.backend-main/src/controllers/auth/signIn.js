import { ApiError, SuccessResponse } from "../../utils/index.js";
import { ENV } from "../../config/index.js";
import Users from './../../models/userSchema.js';
import bcrypt from 'bcrypt';
import jwt from "jsonwebtoken";

const signIn = async (req, res, next) => {
  try {
    const { body: { email, password } } = req;
    const user = await Users.findOne({ email });
    if (!user) {
      throw new ApiError("invalid detail", 400, true, false, "Incorrect email address.")
    }
    const checkPassword = await bcrypt.compare(password, user.password);
    if (!checkPassword) {
      throw new ApiError("invalid detail", 400, true, false, "Incorrect password");
    }
    const token = jwt.sign({ userID: user._id, role: user.role }, ENV.JWT_SECRET, { expiresIn: "24h" });
    return new SuccessResponse(res, 200, true, { user, token: token });
  } catch (error) {
    next(error)
  }
}
export default signIn;