import { SuccessResponse, ApiError } from "../../utils/index.js";
import { ENV } from "../../config/index.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import Users from "../../models/userSchema.js";

const signUp = async (req, res, next) => {
  try {
    const { body: { email, password, role } } = req;
    const ifEmailExist = await Users.findOne({ email });
    if (ifEmailExist) {
      throw new ApiError("Conflict", 409, true, false, "An account with this email address already exists.");
    }
    const hashedPassword = await bcrypt.hash(password, 12);
    const user = new Users({
      email,
      password: hashedPassword,
      role
    });
    await user.save();
    const token = jwt.sign({ userID: user._id, role: user.role }, ENV.JWT_SECRET, { expiresIn: "24h" });
    return new SuccessResponse(res, 201, true, { token: token })
  } catch (error) {
    next(error)
  }
}
export default signUp;