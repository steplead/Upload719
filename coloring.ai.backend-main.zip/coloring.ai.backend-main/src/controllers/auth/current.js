import { SuccessResponse } from "../../utils/index.js";

const current = async (req, res, next) => {
  try {
    const { user: { _id: userID, email, role } } = req;
    return new SuccessResponse(res, 200, true, {email, role});
  } catch (error) {
    next(error)
  }
};
export default current;