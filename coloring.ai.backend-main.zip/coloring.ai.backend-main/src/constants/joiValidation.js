import Joi from "joi";
import passwordValidation from "../utils/passwordValidation.js";

export const SignUpJoiSchema = Joi.object().options({ abortEarly: false }).keys({
  email: Joi.string().email().lowercase().trim().required().messages({
    "any.required": "Email is required",
    "string.email": "Invalid email format",
    "string.base": "Email must be in string",
    "string.empty": "Email empty"
  }),
  password: Joi.string().required().custom((value, helper) => {
    const errors = passwordValidation(value);
    if (errors.length > 0) {
      return helper.message(errors.join(", "));
    }
    return value;
  }).messages({
    "any.required": "Password is required",
    "string.base": "Password must be in string",
    "string.empty": "Password empty"
  }),
  role: Joi.string().required().valid("user", "admin").default("user").messages({
    "any.required": "Role is required",
    "any.only": "Invalid role",
  })
}).unknown(false);


export const SignInJoiSchema = Joi.object().options({ abortEarly: false }).keys({
  email: Joi.string().email().lowercase().trim().required().messages({
    "any.required": "Email is required",
    "string.email": "Invalid email format",
    "string.base": "Email must be in string",
    "string.empty": "Email empty"
  }),
  password: Joi.string().required().messages({
    "any.required": "Password is required",
    "string.base": "Password must be in string",
    "string.empty": "Password empty"
  }),
}).unknown(false);