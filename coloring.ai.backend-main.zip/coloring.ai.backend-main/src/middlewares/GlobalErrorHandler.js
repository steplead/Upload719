import { errorHandler, ApiNotFound, HTTP500Error } from "../utils/index.js";

class GlobalErrorHandler {
  static apiNotFound = (req, res, next) => {
    const API_NOT_FOUND = new ApiNotFound(`This path '${req.path}' not found`);
    return next(API_NOT_FOUND);
  };

  static http500Error = (req, res, next) => {
    const INTERNAL_SERVER_ERROR = new HTTP500Error("Internal server error");
    next(INTERNAL_SERVER_ERROR);
  };

  static trustedError = (error, req, res, next) => {
    if (!errorHandler.isTrustedError(error)) {
      // console.log(error.reason)
      next(error);
    }
    return res.status(error.statusCode ?? 500).json({
      name: error.name,
      statusCode: error.statusCode,
      success: error.success,
      message: error.message,
    });
  };

  static uncaughtException = (error) => {
    console.log(`uncaughtException ${error.message}`);
    process.exit(1);
  };

  static unhandledRejection = (reason) => {
    console.log(`unhandledRejection ${reason}`);
    process.exit(1);
  };
}
export default GlobalErrorHandler;
