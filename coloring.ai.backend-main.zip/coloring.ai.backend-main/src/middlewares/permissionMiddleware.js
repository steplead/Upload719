import { ApiError } from "../utils/index.js";

const permissionMiddleware = async (req, res, next) => {
  try {
    const { user: { role } } = req;
    if (role === "user") {
      throw new ApiError("Forbidden", 403, true, false, "You do not have permission to access this resource.")
    }
    next();
  } catch (error) {
    next(error)
  }
}
export default permissionMiddleware;