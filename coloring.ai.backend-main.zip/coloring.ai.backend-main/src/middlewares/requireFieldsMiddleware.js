import { ApiError } from "../utils/index.js";

const RequiredFiedldsMiddleware = (schema) => {
  const handler = (req, res, next) => {
    try {
      const fields = { ...req.body, ...req.params, ...req.query };
      // console.log(fields)
      const { error } = schema.validate(fields);
      // console.log(error)
      if (error) {
        throw new ApiError("validation error", 400, true, false, `${error.details.map((detail) => detail.message)}`);
      }
      next();
    } catch (error) {
      next(error);
    }
  };
  return handler;
};
export default RequiredFiedldsMiddleware;
