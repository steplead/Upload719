import validateToken from "../utils/validateToken.js";
import Users from "../models/userSchema.js";
import { ApiError } from "../utils/ApiErrors.js";

const authMiddleware = async (req, res, next) => {
  try {
    const token = req.headers.authorization;
    if (!token) {
      throw new ApiError("Not Found", 404, true, false, "Token not found");
    }
    const validate = validateToken(token);
    if (!validate.valid) {
      throw new ApiError("Unauthorized", 401, true, false, validate.message);
    }
    const user = await Users.findOne({ _id: validate.decoded.userID });
    if (!user) throw new ApiError("not found", 404, true, false, "We were unable to locate the requested user.");
    req.user = user;
    next();
  } catch (error) {
    next(error)
  }
};
export default authMiddleware;