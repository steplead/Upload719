import PasswordValidator from "password-validator";

const passwordValidation = (password) => {
  const schema = new PasswordValidator();
  schema.is().min(8).has().uppercase().has().lowercase().has().digits().has().symbols().is().not().oneOf(["Password", "password"]);
  const ifErrors = schema.validate(password, { details: true });
  if (ifErrors.length > 0) {
    const errors = ifErrors.map((error) => error.message.replace("string", "password"));
    return errors;
  }
  return [];
};
export default passwordValidation;
