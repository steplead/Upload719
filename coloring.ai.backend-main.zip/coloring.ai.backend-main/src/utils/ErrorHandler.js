import BaseError from "./BaseError.js";

class ErrorHandler {
  isTrustedError = (error) => {
    if (error instanceof BaseError) {
      return error.isOperational;
    } else if (error instanceof Error) {
      if (error.name == "ValidationError") {
        // const errors = Object.values(error.errors).map((err) => err.message);
        // console.log(errors);
        return true;
      }
    }
    return false;
  };
}
const errorHandler = new ErrorHandler();
export default errorHandler;
