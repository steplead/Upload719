class SuccessResponse {
  constructor(res, statusCode, success, result) {
    this.res = res;
    this.statusCode = statusCode;
    this.success = success;
    this.result = result;

    // call the method
    this.send();
  }

  send = () => {
    this.res.status(this.statusCode).json({
      status: this.statusCode,
      success: this.success,
      result: this.result,
    });
  };
}
export { SuccessResponse };
