class BaseError extends Error {
  constructor(name, statusCode, isOperational, success, message) {
    super(message);
    this.name = name;
    this.statusCode = statusCode;
    this.isOperational = isOperational;
    this.success = success;

    Error.captureStackTrace(this, this.constructor);
  }
}
export default BaseError;
