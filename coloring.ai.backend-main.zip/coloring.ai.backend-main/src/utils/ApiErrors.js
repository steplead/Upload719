import BaseError from "./BaseError.js";

class ApiError extends BaseError {
  constructor(name, statusCode, isOperational, success, message) {
    super(name, statusCode, isOperational, success, message);
  }
}

class ApiNotFound extends BaseError {
  constructor(message) {
    super("Not Found", 404, true, false, message);
  }
}

class HTTP500Error extends BaseError {
  constructor(message = "Internal Server Error") {
    super("Server Error", 500, true, false, message);
  }
}
export { ApiError, ApiNotFound, HTTP500Error };
