import { ENV } from "../config/index.js";
import jwt from "jsonwebtoken";
const { JsonWebTokenError, TokenExpiredError } = jwt;

const validateToken = (bearerToken) => {
  try {
    const token = bearerToken.split(" ")[1];
    const decoded = jwt.verify(token, ENV.JWT_SECRET)
    return {
      valid: true,
      message: "success",
      decoded
    }
  } catch (error) {
    if (error instanceof TokenExpiredError) {
      return {
        valid: false,
        message: "Token expire",
      }
    } else if (error instanceof JsonWebTokenError) {
      return {
        valid: false,
        message: "Malformed token"
      }
    }
    return {
      valid: false,
      message: error.message
    }
  }
};
export default validateToken;