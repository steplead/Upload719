import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    unique: true,
    required: [true, "Email required"],
    lowercase: true,
    trim: true
  },
  role: {
    type: String,
    default: "user",
  },
  password: {
    type: String,
    required: [true, "Password required"],
  }
}, { timestamps: true })
const Users = mongoose.model("User", userSchema);
export default Users;