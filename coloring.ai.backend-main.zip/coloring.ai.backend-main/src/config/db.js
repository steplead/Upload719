import ENV from "./keys.js";
import mongoose from "mongoose";

const DB = async () => {
  try {
    await mongoose.connect(ENV.MongoDB.url);
    mongoose.connection.on("connected", () => {
      console.log(`MongoDB connected`);
    });
    mongoose.connection.on("error", (error) => {
      console.log(error);
      process.emit("unhandledRejection", error);
    });
    console.log(`MongoDB connected (${mongoose.connection.name})`);
  } catch (error) {
    console.log(`Error in MongoDB ${error.message}`);
    process.emit("unhandledRejection", error);
  }
};
export default DB;
