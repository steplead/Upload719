import dotenv from "dotenv";
dotenv.config({ path: ".env.development" });

export default {
  PORT: process.env.PORT || 7001,
  JWT_SECRET: process.env.JWT_SECRET,
  MongoDB: {
    url: process.env.CONNECTION_STRING,
  },
}